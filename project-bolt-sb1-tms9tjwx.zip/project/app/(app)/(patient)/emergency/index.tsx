import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { Phone, Ambulance, ChevronFirst as FirstAid } from 'lucide-react-native';
import i18n from '@/i18n';
import { useAuth } from '@/hooks/useAuth';

const emergencyServices = [
  {
    id: 1,
    name: 'Ambulance',
    icon: Ambulance,
    eta: '8 min',
    distance: '2.3 km',
    image: 'https://images.unsplash.com/photo-1612277635895-b2a4f39bc774?w=800&auto=format&fit=crop',
  },
  {
    id: 2,
    name: 'Médecin urgentiste',
    icon: FirstAid,
    eta: '15 min',
    distance: '3.1 km',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=800&auto=format&fit=crop',
  },
];

export default function EmergencyScreen() {
  const { profile } = useAuth();
  const [selectedService, setSelectedService] = useState(null);
  const [userLocation, setUserLocation] = useState({
    latitude: 33.5731,
    longitude: -7.5898,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });

  return (
    <View style={styles.container}>
      <MapView
        provider={PROVIDER_GOOGLE}
        style={styles.map}
        initialRegion={userLocation}>
        <Marker coordinate={userLocation} title="Votre position" />
        {emergencyServices.map((service) => (
          <Marker
            key={service.id}
            coordinate={{
              latitude: userLocation.latitude + Math.random() * 0.01,
              longitude: userLocation.longitude + Math.random() * 0.01,
            }}
            title={service.name}
          />
        ))}
      </MapView>

      <View style={styles.servicesContainer}>
        <Text style={styles.title}>Services d'urgence</Text>
        <View style={styles.servicesList}>
          {emergencyServices.map((service) => (
            <TouchableOpacity
              key={service.id}
              style={[
                styles.serviceCard,
                selectedService?.id === service.id && styles.selectedCard,
              ]}
              onPress={() => setSelectedService(service)}>
              <Image source={{ uri: service.image }} style={styles.serviceImage} />
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceDetails}>
                  Arrivée estimée: {service.eta}
                </Text>
                <Text style={styles.serviceDetails}>
                  Distance: {service.distance}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={[
            styles.emergencyButton,
            !selectedService && styles.emergencyButtonDisabled,
          ]}
          disabled={!selectedService}>
          <Phone size={24} color="#fff" />
          <Text style={styles.emergencyButtonText}>
            Appeler {selectedService?.name ?? 'un service'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  map: {
    flex: 1,
  },
  servicesContainer: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: '#333',
    marginBottom: 15,
  },
  servicesList: {
    gap: 12,
    marginBottom: 20,
  },
  serviceCard: {
    flexDirection: 'row',
    backgroundColor: '#f8f8f8',
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
  },
  selectedCard: {
    backgroundColor: '#e3f2fd',
    borderColor: '#4A90E2',
    borderWidth: 1,
  },
  serviceImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 12,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#333',
    marginBottom: 4,
  },
  serviceDetails: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#666',
  },
  emergencyButton: {
    backgroundColor: '#FF3B30',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  emergencyButtonDisabled: {
    opacity: 0.7,
  },
  emergencyButtonText: {
    color: '#fff',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});