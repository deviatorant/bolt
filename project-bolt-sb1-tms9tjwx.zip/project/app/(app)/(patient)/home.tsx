import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Bell, MapPin, Clock, Calendar, Search } from 'lucide-react-native';

const upcomingAppointment = {
  doctor: "Dr. Sophie Martin",
  specialty: "Médecin généraliste",
  date: "Aujourd'hui, 14:30",
  image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop"
};

const services = [
  { id: 1, name: "Consultation à domicile", icon: "🏠" },
  { id: 2, name: "Téléconsultation", icon: "📱" },
  { id: 3, name: "Urgences", icon: "🚑" },
  { id: 4, name: "Pharmacies", icon: "💊" },
];

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Bonjour, Ahmed 👋</Text>
          <View style={styles.location}>
            <MapPin size={16} color="#666" />
            <Text style={styles.locationText}>Casablanca, Maroc</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.notificationButton}>
          <Bell size={24} color="#333" />
          <View style={styles.notificationBadge} />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <Search size={20} color="#666" />
        <Text style={styles.searchPlaceholder}>Rechercher un médecin, un service...</Text>
      </View>

      {upcomingAppointment && (
        <View style={styles.appointmentCard}>
          <View style={styles.appointmentHeader}>
            <Text style={styles.appointmentTitle}>Prochain rendez-vous</Text>
            <Clock size={16} color="#4A90E2" />
          </View>
          <View style={styles.appointmentContent}>
            <Image
              source={{ uri: upcomingAppointment.image }}
              style={styles.doctorImage}
            />
            <View style={styles.appointmentInfo}>
              <Text style={styles.doctorName}>{upcomingAppointment.doctor}</Text>
              <Text style={styles.doctorSpecialty}>{upcomingAppointment.specialty}</Text>
              <View style={styles.appointmentTime}>
                <Calendar size={14} color="#666" />
                <Text style={styles.timeText}>{upcomingAppointment.date}</Text>
              </View>
            </View>
          </View>
        </View>
      )}

      <View style={styles.servicesContainer}>
        <Text style={styles.sectionTitle}>Nos services</Text>
        <View style={styles.servicesGrid}>
          {services.map((service) => (
            <TouchableOpacity key={service.id} style={styles.serviceCard}>
              <Text style={styles.serviceIcon}>{service.icon}</Text>
              <Text style={styles.serviceName}>{service.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 60,
  },
  greeting: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 24,
    color: '#333',
    marginBottom: 4,
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  notificationButton: {
    position: 'relative',
    padding: 8,
  },
  notificationBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 8,
    height: 8,
    backgroundColor: '#FF3B30',
    borderRadius: 4,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    margin: 20,
    padding: 16,
    borderRadius: 12,
    gap: 12,
  },
  searchPlaceholder: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#666',
  },
  appointmentCard: {
    margin: 20,
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  appointmentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  appointmentTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#333',
  },
  appointmentContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  doctorImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 16,
  },
  appointmentInfo: {
    flex: 1,
  },
  doctorName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#333',
    marginBottom: 4,
  },
  doctorSpecialty: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  appointmentTime: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  timeText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#666',
  },
  servicesContainer: {
    padding: 20,
  },
  sectionTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: '#333',
    marginBottom: 16,
  },
  servicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  serviceCard: {
    width: '47%',
    backgroundColor: '#F5F5F5',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
  },
  serviceIcon: {
    fontSize: 32,
    marginBottom: 12,
  },
  serviceName: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
  },
});