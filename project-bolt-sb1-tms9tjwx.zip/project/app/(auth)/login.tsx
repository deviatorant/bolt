import { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Image } from 'react-native';
import { Link, router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { User, Lock, Languages } from 'lucide-react-native';
import { supabase } from '@/utils/supabase';
import i18n from '@/i18n';

export default function LoginScreen() {
  const [userType, setUserType] = useState<'patient' | 'professional'>('patient');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('type')
        .eq('id', data.user.id)
        .single();

      if (profileError) throw profileError;

      if (profile.type !== userType) {
        throw new Error('Type de compte incorrect');
      }

      if (userType === 'patient') {
        router.replace('/(app)/(patient)/home');
      } else {
        router.replace('/(app)/(professional)/dashboard');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleLanguage = () => {
    i18n.locale = i18n.locale === 'fr' ? 'ar' : 'fr';
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#4A90E2', '#357ABD']}
        style={styles.header}
      >
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1651008376811-b90baee60c1f?w=800&auto=format&fit=crop' }}
          style={styles.logo}
        />
        <Text style={styles.title}>SantéConnect</Text>
      </LinearGradient>

      <View style={styles.content}>
        {error && (
          <Text style={styles.errorText}>{error}</Text>
        )}

        <View style={styles.userTypeSelector}>
          <TouchableOpacity
            style={[styles.userTypeButton, userType === 'patient' && styles.userTypeButtonActive]}
            onPress={() => setUserType('patient')}
          >
            <Text style={[styles.userTypeText, userType === 'patient' && styles.userTypeTextActive]}>
              {i18n.t('patient')}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.userTypeButton, userType === 'professional' && styles.userTypeButtonActive]}
            onPress={() => setUserType('professional')}
          >
            <Text style={[styles.userTypeText, userType === 'professional' && styles.userTypeTextActive]}>
              {i18n.t('professional')}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.form}>
          <View style={styles.inputContainer}>
            <User size={20} color="#666" style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder={i18n.t('email')}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              keyboardType="email-address"
              editable={!loading}
            />
          </View>

          <View style={styles.inputContainer}>
            <Lock size={20} color="#666" style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder={i18n.t('password')}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!loading}
            />
          </View>

          <TouchableOpacity 
            style={[styles.loginButton, loading && styles.loginButtonDisabled]}
            onPress={handleLogin}
            disabled={loading}
          >
            <Text style={styles.loginButtonText}>
              {loading ? 'Chargement...' : i18n.t('login')}
            </Text>
          </TouchableOpacity>

          <Link href="/register" asChild>
            <TouchableOpacity style={styles.registerButton}>
              <Text style={styles.registerButtonText}>{i18n.t('register')}</Text>
            </TouchableOpacity>
          </Link>
        </View>
      </View>

      <TouchableOpacity style={styles.languageButton} onPress={toggleLanguage}>
        <Languages size={24} color="#4A90E2" />
        <Text style={styles.languageButtonText}>
          {i18n.locale === 'fr' ? 'عربي' : 'Français'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 40,
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 10,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 24,
    color: '#fff',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  errorText: {
    color: '#FF3B30',
    textAlign: 'center',
    marginBottom: 20,
    fontFamily: 'Inter-Regular',
  },
  userTypeSelector: {
    flexDirection: 'row',
    backgroundColor: '#F5F5F5',
    borderRadius: 12,
    padding: 4,
    marginBottom: 30,
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  userTypeButtonActive: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  userTypeText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#666',
  },
  userTypeTextActive: {
    fontFamily: 'Inter-SemiBold',
    color: '#4A90E2',
  },
  form: {
    gap: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 12,
    paddingHorizontal: 16,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    paddingVertical: 16,
    color: '#333',
  },
  loginButton: {
    backgroundColor: '#4A90E2',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  loginButtonDisabled: {
    opacity: 0.7,
  },
  loginButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    color: '#fff',
  },
  registerButton: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  registerButtonText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#4A90E2',
  },
  languageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  languageButtonText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#4A90E2',
  },
});