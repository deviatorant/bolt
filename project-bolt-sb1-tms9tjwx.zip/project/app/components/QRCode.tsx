import { View, Text, StyleSheet } from 'react-native';
import QRCode from 'react-native-qrcode-svg';

interface QRCodeDisplayProps {
  url: string;
}

export default function QRCodeDisplay({ url }: QRCodeDisplayProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Scanner pour tester l'application</Text>
      <View style={styles.qrContainer}>
        <QRCode
          value={url}
          size={200}
          color="#333333"
          backgroundColor="#ffffff"
        />
      </View>
      <Text style={styles.url}>{url}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333333',
    marginBottom: 20,
  },
  qrContainer: {
    padding: 20,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    marginBottom: 20,
  },
  url: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#666666',
  },
});