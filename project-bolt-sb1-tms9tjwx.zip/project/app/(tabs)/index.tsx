import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';

const featuredRecipe = {
  title: "Ratatouille Provençale",
  image: "https://images.unsplash.com/photo-1592417817098-8fd3d9eb14a5?w=800&auto=format&fit=crop",
  duration: "45 min",
  difficulty: "Moyen"
};

const categories = [
  { id: 1, name: "Entrées", icon: "🥗" },
  { id: 2, name: "Plats", icon: "🍝" },
  { id: 3, name: "Desserts", icon: "🍰" },
  { id: 4, name: "Boissons", icon: "🍹" },
];

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Bonjour 👋</Text>
        <Text style={styles.subtitle}>Que voulez-vous cuisiner aujourd'hui ?</Text>
      </View>

      <View style={styles.featuredContainer}>
        <Text style={styles.sectionTitle}>Recette du Jour</Text>
        <TouchableOpacity style={styles.featuredCard}>
          <Image
            source={{ uri: featuredRecipe.image }}
            style={styles.featuredImage}
          />
          <View style={styles.featuredContent}>
            <Text style={styles.featuredTitle}>{featuredRecipe.title}</Text>
            <View style={styles.featuredMeta}>
              <Text style={styles.metaText}>⏱ {featuredRecipe.duration}</Text>
              <Text style={styles.metaText}>📊 {featuredRecipe.difficulty}</Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.categoriesContainer}>
        <Text style={styles.sectionTitle}>Catégories</Text>
        <View style={styles.categoriesGrid}>
          {categories.map((category) => (
            <TouchableOpacity key={category.id} style={styles.categoryCard}>
              <Text style={styles.categoryIcon}>{category.icon}</Text>
              <Text style={styles.categoryName}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    padding: 20,
    paddingTop: 40,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '600',
    color: '#333333',
  },
  subtitle: {
    fontSize: 16,
    color: '#666666',
    marginTop: 5,
  },
  featuredContainer: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333333',
    marginBottom: 15,
  },
  featuredCard: {
    backgroundColor: '#ffffff',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  featuredImage: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  featuredContent: {
    padding: 15,
  },
  featuredTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333333',
  },
  featuredMeta: {
    flexDirection: 'row',
    marginTop: 10,
    gap: 15,
  },
  metaText: {
    color: '#666666',
    fontSize: 14,
  },
  categoriesContainer: {
    padding: 20,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
  },
  categoryCard: {
    backgroundColor: '#f8f8f8',
    borderRadius: 12,
    padding: 15,
    width: '47%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  categoryName: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '500',
  },
});