import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity } from 'react-native';

const recipes = [
  {
    id: '1',
    title: 'Coq au Vin',
    image: 'https://images.unsplash.com/photo-1600891964092-4316c288032e?w=800&auto=format&fit=crop',
    duration: '1h 30min',
    difficulty: 'Difficile',
  },
  {
    id: '2',
    title: 'Salade Niçoise',
    image: 'https://images.unsplash.com/photo-1511357840105-748c95f0a7e4?w=800&auto=format&fit=crop',
    duration: '20min',
    difficulty: 'Facile',
  },
  {
    id: '3',
    title: 'Tarte Tatin',
    image: 'https://images.unsplash.com/photo-1519915028121-7d3463d20b13?w=800&auto=format&fit=crop',
    duration: '45min',
    difficulty: 'Moyen',
  },
];

export default function RecipesScreen() {
  const renderRecipeCard = ({ item }) => (
    <TouchableOpacity style={styles.recipeCard}>
      <Image source={{ uri: item.image }} style={styles.recipeImage} />
      <View style={styles.recipeContent}>
        <Text style={styles.recipeTitle}>{item.title}</Text>
        <View style={styles.recipeMeta}>
          <Text style={styles.metaText}>⏱ {item.duration}</Text>
          <Text style={styles.metaText}>📊 {item.difficulty}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={recipes}
        renderItem={renderRecipeCard}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  listContainer: {
    padding: 20,
    gap: 20,
  },
  recipeCard: {
    backgroundColor: '#ffffff',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  recipeImage: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  recipeContent: {
    padding: 15,
  },
  recipeTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333333',
  },
  recipeMeta: {
    flexDirection: 'row',
    marginTop: 10,
    gap: 15,
  },
  metaText: {
    color: '#666666',
    fontSize: 14,
  },
});