import { I18n } from 'i18n-js';
import { getLocales } from 'expo-localization';

const i18n = new I18n({
  fr: {
    welcome: 'Bienvenue sur SantéConnect',
    login: 'Se connecter',
    register: 'Créer un compte',
    email: 'Email',
    password: 'Mot de passe',
    patient: 'Patient',
    professional: 'Professionnel de santé',
    home: 'Accueil',
    appointments: 'Rendez-vous',
    teleconsultation: 'Téléconsultation',
    emergency: 'Urgences',
    profile: 'Profil',
    search: 'Rechercher',
    searchPlaceholder: 'Rechercher un médecin, un service...',
    upcomingAppointment: 'Prochain rendez-vous',
    services: 'Nos services',
    homeVisit: 'Consultation à domicile',
    videoConsult: 'Téléconsultation',
    emergency: 'Urgences',
    pharmacy: 'Pharmacies',
  },
  ar: {
    welcome: 'مرحبا بكم في SantéConnect',
    login: 'تسجيل الدخول',
    register: 'إنشاء حساب',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    patient: 'مريض',
    professional: 'مهني صحي',
    home: 'الرئيسية',
    appointments: 'المواعيد',
    teleconsultation: 'الاستشارة عن بعد',
    emergency: 'الطوارئ',
    profile: 'الملف الشخصي',
    search: 'بحث',
    searchPlaceholder: 'البحث عن طبيب أو خدمة...',
    upcomingAppointment: 'الموعد القادم',
    services: 'خدماتنا',
    homeVisit: 'استشارة منزلية',
    videoConsult: 'استشارة عن بعد',
    emergency: 'طوارئ',
    pharmacy: 'صيدليات',
  },
});

// Définir la langue par défaut
i18n.locale = getLocales()[0].languageCode;

export default i18n;