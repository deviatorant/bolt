/*
  # Schéma initial de l'application de santé

  1. Tables Principales
    - `profiles`
      - Informations de base des utilisateurs (patients et professionnels)
    - `professionals`
      - Détails spécifiques aux professionnels de santé
    - `appointments`
      - Rendez-vous entre patients et professionnels
    - `messages`
      - Système de messagerie
    - `payments`
      - Transactions et paiements
    - `medical_specialties`
      - Spécialités médicales
    
  2. Sécurité
    - RLS activé sur toutes les tables
    - Politiques d'accès selon le rôle utilisateur
*/

-- Création des types énumérés
CREATE TYPE user_type AS ENUM ('patient', 'professional');
CREATE TYPE appointment_status AS ENUM ('pending', 'confirmed', 'cancelled', 'completed');
CREATE TYPE payment_status AS ENUM ('pending', 'completed', 'failed', 'refunded');
CREATE TYPE consultation_type AS ENUM ('in_person', 'video', 'home');

-- Table des profils utilisateurs
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  type user_type NOT NULL,
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  address TEXT,
  city TEXT,
  language TEXT DEFAULT 'fr',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Table des professionnels de santé
CREATE TABLE professionals (
  id UUID PRIMARY KEY REFERENCES profiles(id),
  specialty TEXT NOT NULL,
  license_number TEXT,
  education TEXT,
  experience TEXT,
  consultation_fee DECIMAL(10,2),
  availability JSON,
  rating DECIMAL(2,1),
  is_verified BOOLEAN DEFAULT false
);

-- Table des rendez-vous
CREATE TABLE appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID REFERENCES profiles(id),
  professional_id UUID REFERENCES professionals(id),
  date_time TIMESTAMPTZ NOT NULL,
  duration INTEGER NOT NULL, -- en minutes
  type consultation_type NOT NULL,
  status appointment_status DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Table des messages
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID REFERENCES profiles(id),
  receiver_id UUID REFERENCES profiles(id),
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Table des paiements
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id UUID REFERENCES appointments(id),
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'MAD',
  status payment_status DEFAULT 'pending',
  payment_method TEXT,
  transaction_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Activation de la sécurité RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE professionals ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Politiques de sécurité pour les profils
CREATE POLICY "Les utilisateurs peuvent lire leur propre profil"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Les utilisateurs peuvent modifier leur propre profil"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Politiques pour les professionnels
CREATE POLICY "Tout le monde peut voir les professionnels vérifiés"
  ON professionals FOR SELECT
  USING (is_verified = true);

-- Politiques pour les rendez-vous
CREATE POLICY "Les patients peuvent voir leurs rendez-vous"
  ON appointments FOR SELECT
  USING (auth.uid() = patient_id);

CREATE POLICY "Les professionnels peuvent voir leurs rendez-vous"
  ON appointments FOR SELECT
  USING (auth.uid() = professional_id);

-- Politiques pour les messages
CREATE POLICY "Les utilisateurs peuvent voir leurs messages"
  ON messages FOR SELECT
  USING (auth.uid() IN (sender_id, receiver_id));

CREATE POLICY "Les utilisateurs peuvent envoyer des messages"
  ON messages FOR INSERT
  WITH CHECK (auth.uid() = sender_id);

-- Politiques pour les paiements
CREATE POLICY "Les utilisateurs peuvent voir leurs paiements"
  ON payments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM appointments
      WHERE appointments.id = payments.appointment_id
      AND (appointments.patient_id = auth.uid() OR appointments.professional_id = auth.uid())
    )
  );

-- Fonction pour mettre à jour le timestamp updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers pour mettre à jour updated_at
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_appointments_updated_at
    BEFORE UPDATE ON appointments
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payments_updated_at
    BEFORE UPDATE ON payments
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();